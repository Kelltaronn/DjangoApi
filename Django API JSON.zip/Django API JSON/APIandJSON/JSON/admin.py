from django.contrib import admin
from .models import Currency, Koncert
# Register your models here.
admin.site.register(Currency)
admin.site.register(Koncert)