from django.shortcuts import render

#API and RESTAPI imports
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status

from django.core.exceptions import ObjectDoesNotExist

#Decorator import
from django.views.decorators.http import require_http_methods, require_GET ,require_POST

#models
from .models import Koncert,Currency ,Error ,Success

#Forms
from .form import KoncertForm, CurrencyForm

#serializer
from .serializer import KoncertSerializer, CurrencySerializer ,JsonErrors ,JsonSuccess

#Json Byte to string
import json

#logging imports
import logging

#logging fuction
logging.basicConfig(filename='logging.log', encoding='utf-8', level=logging.DEBUG,
                    format='%(asctime)s - %(message)s', datefmt='%d-%b-%y %H:%M:%S')

# Create your views here.

#Basic form page:
@require_GET
def form_view(request):
    context = {
        "form": KoncertForm()
    }
    return render(request,'form.html',context)

@require_POST
def send_form(request):
    registrated_data= KoncertForm(request.POST)
    print(registrated_data.data)
    if registrated_data.is_valid():
        registrated_data.save()
    else:
        context ={
            "errors": registrated_data.errors.as_data()
        }
    return render(request,'form.html',context)

def form_function(request):
    if request.method == "POST":
        return send_form(request)
    else:
        return form_view(request)
    
#Returned Data during registration:
""" <QueryDict: {'csrfmiddlewaretoken': ['XHh7yiBVF3q0Hyj9I6DOK5jd4Lf4cfvmmF5YXdlQwTpqPyPx9eHFPg5mWa3Dh2iL'],
              'time': ['2000'], 'place': ['Budapest'], 
              'band': ['Valaki'], 'currency': ['1'], 'price': ['5000']}> """


# Apiview

class KoncertApiView(APIView):
    def get(self,request):
        conterts = Koncert.objects.all()
        contert_serializer = KoncertSerializer(conterts, many=True) # many= True ha többet kérek le.
        return Response(contert_serializer.data,status=status.HTTP_200_OK)
    
    def post(self,request):
        bytes = json.loads(request.body)
        concert = Koncert(place = bytes["place"], price = bytes["bytes"],band=bytes["band"],time=bytes["time"])
        concert.save()
        return Response("OK",status=status.HTTP_200_OK)



#ID number search:
class IDApiview(APIView):
    def get(self,request,id):
        try:
            concert = Koncert.objects.get(id=id)
            Id_serializer =KoncertSerializer(concert, many=False)
            return Response(Id_serializer.data, status=status.HTTP_200_OK)
        except ObjectDoesNotExist:
            message = Error(f"Object not found under {id}")
            serialized_message = JsonErrors(message, many=False)
            return Response(serialized_message.data, status=status.HTTP_404_NOT_FOUND)
        

#Api form:
class KoncertFormApi(APIView):
    def post(self,request):
        print(request.content_type)
        #Variables set:
        print(type(request))
        #sent_data=json.loads(request.body)
        sent_data = request.data
        print(type(sent_data))
        contert = KoncertForm(sent_data)


        #Functions:
        if contert.is_valid():
            message = Success(f'Object has been registrated')
            serialized_message = JsonSuccess(message,many=False)
            contert.save()
            return Response(serialized_message.data, status=status.HTTP_201_CREATED)
        else:
            message=Error(f'Object is not valid')
            serialized_message = JsonErrors(message,many=False)
            return Response(serialized_message.data,status=status.HTTP_406_NOT_ACCEPTABLE)




        

