# Form import
from django import forms

#Model import
from .models import Koncert,Currency

class CurrencyForm(forms.ModelForm):
    class Meta:
        model = Currency
        fields ={
            "currency"
        }

class KoncertForm(forms.ModelForm):
    class Meta:
        model = Koncert
        fields = {
            "currency",
            "place",
            "band",
            "time",
            "price",
            
        }



