from rest_framework import serializers
from .models import Koncert, Currency , Error ,Success


class CurrencySerializer(serializers.ModelSerializer):
    class Meta:
        model = Currency
        fields = [
            "currency",
        ]

class KoncertSerializer(serializers.ModelSerializer):
    class Meta:
        model = Koncert
        fields = [
                "place",
                "band",
                "price",
                "time",
                "currency",
        ]

# Errors 
class JsonErrors(serializers.ModelSerializer):
    class Meta:
        model = Error
        fields = [
            "message"
        ]

#Success
class JsonSuccess(serializers.ModelSerializer):
    class Meta:
        model = Success
        fields = [
            "message"
        ]