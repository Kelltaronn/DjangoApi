from django.db import models

# Create your models here.
class Currency(models.Model):
    currency = models.CharField(max_length=255)

class Koncert(models.Model):
    place = models.CharField(max_length=255)
    band = models.CharField(max_length=255)
    price = models.FloatField(editable=True)
    time = models.DateField()
    currency = models.ForeignKey(Currency,null=True, blank=True,on_delete=models.PROTECT)

# Errors
class Error(models.Model):
    message = models.CharField(max_length=255)

#Success
class Success(models.Model):
    message = models.CharField(max_length=255)


